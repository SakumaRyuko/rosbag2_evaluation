# Copyright 2017 Apex.AI, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Script to run a batch of performance experiments."""
from enum import Enum
import itertools
import os
import signal
import subprocess
import sys
import yaml
import datetime
import generate_cmd as gc
import time

#generate_command.pyから取得する

#eval.pyでこのプログラムを実行する際のコマンドライン引数を取得
record_product = list(gc.get_record_product()[int(sys.argv[1])]) #argv[1]番目のrecordのパラメータ
perf_test_product = list(gc.get_perf_test_product()[int(sys.argv[2])]) # argv[2]番目のperf_testのパラメータ
bagfile_path = sys.argv[3] #argv[3]のパスにbagfileを作成
num_of_pbulish = gc.get_perf_test_num_of_pbulish()
#10000/rate+数秒、perf_test,rosbag2 recordを実行する
experiment_length = (int(num_of_pbulish[0])/int(perf_test_product[1])) + 1

#recordコマンドを作成
record_nd_cmd = ""
record_mcs_cmd = ""
base_spp_cmd = ""
record_spp_cmd = ""
record_qos_cmd = f"record_qos_override/{perf_test_product[0]}/{record_product[0]}:{record_product[1]}.yaml"
record_cmd = ""

if record_product[2] == "true":
    record_nd_cmd = "--no-discovery"

record_mcs_cmd = f"{record_product[3]}"

if record_product[4] == "resilient":
    base_spp_cmd = "--storage-preset-profile"
    record_spp_cmd = f"{record_product[4]}"

record_cmd =  f"ros2 bag record /test_{perf_test_product[0]} -o {bagfile_path}" 
record_cmd_option = f" --qos-profile-overrides-path {record_qos_cmd} {record_nd_cmd} --max-cache-size {record_mcs_cmd} {base_spp_cmd} {record_spp_cmd} "
record_cmd += record_cmd_option

record_process = None

done_experiment = False

current_index = 0 #1回だけ実行


class Type(Enum):
    """Define the enumeration for the experiment types."""

    PUBLISHER = 0
    SUBSCRIBER = 1
    BOTH = 2


class Instance:
    """perf_test process encapsulation."""

    def __init__(self, operation_type):
        """
        Construct the object.
        
        :param operation_type: Type of the operation
        """
        self.product = perf_test_product
        self.process = None

        self.type = operation_type

    def run(self, index):
        """
        Run the embedded perf_test process.

        :param index: The test configuration to run.
        """
        global record_process
        if record_product[2] == "true": #no discoveryがONなら、perf_testを先に起動し、トピックを作成、メッセージをパブリッシュするまでにレコードを起動
            self.process = subprocess.Popen(self.perf_cmd(index), shell=True)
            time.sleep(0.2)
            record_process = subprocess.Popen(record_cmd,shell=True)
        else:
            record_process = subprocess.Popen(record_cmd,shell=True)
            self.process = subprocess.Popen(self.perf_cmd(index), shell=True)
        # record_process = subprocess.Popen(record_cmd,shell=True)
        # time.sleep(0.1)
        # self.process = subprocess.Popen(self.perf_cmd(index), shell=True)

    def perf_cmd(self, index):
        """
        Return the command line necessary to execute the performance test.

        :param index: The test configuration the returned command line should
            contain.
        :return: The command line argument to execute the performance test.
        """
        global record_cmd

        command = 'ros2 run performance_test perf_test'

        c = self.product
        #c = [type_of_msg, rate, num_of_sub, reliability, durability, dds]
        if self.type == Type.PUBLISHER:
            c[2] = '0'
            pubs_args = ' -p 1 '
        elif self.type == Type.SUBSCRIBER:
            pubs_args = ' -p 0 '
        elif self.type == Type.BOTH:
            pubs_args = ' -p 1 '
        else:
            raise ValueError('Unsupported type')

        fixed_args = ' --communication rclcpp-single-threaded-executor '

        topic_name = f'test_{c[0]}' #トピックの名前を逐次変更する(理由：Only topics with one type are supported)
        perf_test_qos_r = ""
        perf_test_qos_d = ""
        if c[3] == "reliable":
            perf_test_qos_r = "--reliable"
        if c[4] == "transient":
            perf_test_qos_d = "--transient"
        dyn_args = f" --msg {c[0]} --topic {topic_name} --rate {c[1]} -s {c[2]} {perf_test_qos_r} {perf_test_qos_d}"

        print('*********perf_test_command**********')
        print(command + ' ' + fixed_args + dyn_args + pubs_args)

        #recordコマンド
        print('*********record_command**********')
        print(record_cmd)
        print('*******************')
        #record開始(envコマンドを使用するためコマンド全体を''で分割)
        # record_process = subprocess.Popen(['ros2', 'bag', 'record',
        #     topic_name, '-o', bagfile_path,'--qos-profile-overrides-path',record_qos_cmd,
        #     record_nd_cmd,'--max-cache-size',record_mcs_cmd,base_cpp_cmd,record_spp_cmd],shell=True)
        # record_process = subprocess.Popen(record_cmd,shell=True)

        return command + ' ' + fixed_args + dyn_args + pubs_args

    def kill(self):
        """Kill the associated performance test process."""
        if self.process is not None:
            self.process.kill()

    def num_runs(self):
        """Return the number of experiments runs this instance can execute."""
        return len(self.product)

    def __del__(self):#デストラクタ
        """Kill the associated performance test process."""
        self.kill()



num_pub_processes = 1

# publisher = [Instance(Type.PUBLISHER) for _ in range(0, num_pub_processes)]
publisher = Instance(Type.PUBLISHER)
def signal_handler(sig, frame):
    """Signal handler to handle Ctrl-C."""
    print('You pressed Ctrl+C! Terminating experiment')
    subprocess.Popen('killall -2 perf_test', shell=True)
    subprocess.Popen('killall -2 ros2 bag record', shell=True)
    sys.exit(0)


def timer_handler(sig=None, frame=None):
    """Signal handler to handle the timer."""
    global current_index
    global publisher
    global done_experiment
    # [e.kill() for e in publisher]
    publisher.kill()
    subprocess.Popen('killall -2 perf_test', shell=True)

    #recordをkill
    if(record_process is not None):
        subprocess.Popen('killall -2 perf_test', shell=True)
        time.sleep(0.5)
        subprocess.Popen('killall -2 ros2 bag record', shell=True)
        publisher.kill()
        done_experiment = True
    if(done_experiment == True):
        print('Done with experiments.')
        exit(0)
    else:
        # [e.run(current_index) for e in publisher]
        publisher.run(current_index)


signal.signal(signal.SIGALRM, timer_handler)
signal.signal(signal.SIGINT, signal_handler)
signal.setitimer(signal.ITIMER_REAL, experiment_length, experiment_length)

timer_handler()
print('Press Ctrl+C to abort experiment')
while True:
    signal.pause()
    print('Next experiment.')
